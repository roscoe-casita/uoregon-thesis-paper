This zip package contains uothesis.cls file and sample files you may use with the class file.
Keep all the files in the same folder.

The sample package includes:

readme.txt: this readme file
uothesis.cls: LaTex class file
main.tex: the main component file, that calls for all the rest of the files
abstract.tex: creates abstract page
acknowledgements: creates acknowledgement page
cover: creates cover page
cv: creates curriculum vitae page
dedication: creates dedication page (optional)
chapter1.tex: sample chapter 1
samplefigure1.png: sample figure that is used in chapter 1
chapter2.tex: sample chapter 2
chapter3.tex: sample chapter 3
appendix1.tex: sample appendix page
disbib.bib: sample bibliography data file

All the files except for the dedication and acknowledgement pages are necessary to compile without error using the class file.  

